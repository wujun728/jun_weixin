package com.github.sd4324530.fastweixin.api.entity;

/**
 * @author peiyu
 */
public class UpstreamMsgDistMonth extends UpstreamMsgDist {
}
