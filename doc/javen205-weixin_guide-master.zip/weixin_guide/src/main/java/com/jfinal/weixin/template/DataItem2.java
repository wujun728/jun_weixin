/**
 * Copyright (c) 2015-2016, Javen Zhou  (javenlife@126.com).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package com.jfinal.weixin.template;
/**
 * @author Javen
 * 2016年3月19日
 */
public class DataItem2 extends DataItem{
	private TempItem keyword1;
	private TempItem keyword2;
	private TempItem keyword3;
	private TempItem keyword4;
	private TempItem keyword5;
	private TempItem keyword6;
	private TempItem keyword7;
	private TempItem keyword8;
	
	
	public TempItem getKeyword1() {
		return keyword1;
	}
	public void setKeyword1(TempItem keyword1) {
		this.keyword1 = keyword1;
	}
	public TempItem getKeyword2() {
		return keyword2;
	}
	public void setKeyword2(TempItem keyword2) {
		this.keyword2 = keyword2;
	}
	public TempItem getKeyword3() {
		return keyword3;
	}
	public void setKeyword3(TempItem keyword3) {
		this.keyword3 = keyword3;
	}
	public TempItem getKeyword4() {
		return keyword4;
	}
	public void setKeyword4(TempItem keyword4) {
		this.keyword4 = keyword4;
	}
	public TempItem getKeyword5() {
		return keyword5;
	}
	public void setKeyword5(TempItem keyword5) {
		this.keyword5 = keyword5;
	}
	public TempItem getKeyword6() {
		return keyword6;
	}
	public void setKeyword6(TempItem keyword6) {
		this.keyword6 = keyword6;
	}
	public TempItem getKeyword7() {
		return keyword7;
	}
	public void setKeyword7(TempItem keyword7) {
		this.keyword7 = keyword7;
	}
	public TempItem getKeyword8() {
		return keyword8;
	}
	public void setKeyword8(TempItem keyword8) {
		this.keyword8 = keyword8;
	}
	
	
	
}
